import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from transmission import transmission_curves


csv_file = "D:/experiment-Master_Thesis/data-file_g.csv"
df = pd.read_csv(csv_file)

T_list = np.array([])
delta_v_array = df["Δv(z = 2)"]


def T_calc(i):
    velocity_offsets, T = transmission_curves(i, 'D:/Thesis/21cmFAST-master/Output/Tot_Tau_lists/output')
    return T

def square(x):
    return np.linspace(0,x, 10)
    print(x)

def save_csv(results):
    np.savetxt('output.csv', np.array(list(results)), delimiter =',')


def main():
    
    with multiprocessing.Pool(processes=5) as pool:
        results = pool.imap(square, range(len(delta_v_array))[:100])
    
        save_csv(list(results))
